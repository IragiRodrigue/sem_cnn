# Corrected Three-Paper-Grounded Simulation

This package reruns the device, BPM durability, and grid/HESS models after rebuilding the master database from the three papers.

## Critical correction
TNO / FeMn(NbTa)2O6 is the primary device catalyst.  
CTr is used only as a reduced-columbite HER descriptor benchmark.  
FRNO is used as a mechanistic benchmark, not as the main seawater device catalyst.

## Paper-grounded anchors
- TNO AEMWE: 1.81 V at 700 mA/cm2
- TNO AEMWE stability: ~1.85 V at 800 mA/cm2 for 200 h
- TNO OER: eta50 = 300 mV, eta200 = 419 mV
- TNO OER Tafel slope: 48 mV/dec
- TNO Cdl: 2.08 mF/cm2
- CTr DeltaG_H*(Mn): 0.08 eV as descriptor only

## Main uncertainty
Direct seawater chloride chemistry is not validated by the three papers.
Therefore the model reports optimistic/base/conservative scenarios.

## Files
- 00_parameter_traceability.csv
- 01_corrected_device_dynamic_timeseries.csv
- 01_corrected_device_summary.csv
- 02_BPM_membrane_durability_5000h_timeseries.csv
- 02_BPM_membrane_durability_5000h_summary.csv
- 03_grid_HESS_timeseries_corrected.csv
- 03_grid_HESS_summary_corrected.csv
- corrected_three_paper_grounded_simulation.sqlite
- plots and summary JSON
