# Publication-Grade Master Database from Three Papers

This database was rebuilt before further simulation to separate:
1. paper-extracted experimental values,
2. paper-extracted DFT/mechanistic descriptors,
3. spectroscopy/structural descriptors,
4. previous project simulation outputs,
5. missing validation data required before recalibrating COMSOL/grid/HESS models.

The three papers are coded as:
- P1_FRNO_2023: Ru-engineered FRNO pH-universal water splitting paper.
- P2_TNO_2025: FeMn(NbTa)2O6 AEM water electrolyzer paper.
- P3_CTr_2022: reduced columbite-tantalite CTr water splitting paper.

Important modeling rule:
Do not mix measured values and simulated values without checking the `source_type` and `status` fields.
