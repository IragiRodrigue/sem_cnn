# Proposal-Specific BPM Digital Twin

## Architecture
The generic BPM model was replaced with the proposal-specific membrane:

- AEL: p-TPQA
- Junction: electrospun Nb2O5 catalytic nanofiber interface
- CEL: p-TPSA
- Total BPM thickness: 200 µm

## Operating condition
- Electrolyte: 1 M KOH + 0.5 M NaCl
- Baseline temperature: 30 °C
- Sensitivity temperature: 80 °C
- Baseline current density: 0.5 A/cm²
- Durability target: >1000 h

## Important correction
This BPM model is now aligned with the MSCA proposal chemistry. However, several parameters remain estimated:
- IEC
- water uptake
- AEL conductivity
- CEL conductivity
- Cl- permeability
- Nb2O5 junction water-dissociation activity

## Outputs
- steady-state voltage and selectivity map
- 1000 h dynamic cycling voltage drift
- resistance growth
- chloride/CER risk
- thickness/conductivity design window
- SQLite database for future COMSOL coupling

## Key interpretation
The p-TPQA/Nb2O5/p-TPSA BPM architecture can plausibly meet the >95% OER selectivity target under the modeled conditions, but the final credibility depends on direct measurement of Cl- crossover and Cl2/OCl- production.
